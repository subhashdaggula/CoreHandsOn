using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.HttpsPolicy;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.FileProviders;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;

namespace TestWebApp
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddControllersWithViews();
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env, ILogger<Startup> logger)
        {
            
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
                //app.UseExceptionHandler("/Error.html");
            }
            
            app.UseMyMiddleware();
            //app.UseLogger();
            //app.UseMiddleware<LoggerMiddleware>();

            app.UseStatusCodePages();
            
            //DefaultFilesOptions defaultFilesOptions = new DefaultFilesOptions();
            //defaultFilesOptions.DefaultFileNames.Clear();
            //defaultFilesOptions.DefaultFileNames.Add("Custom.html");
            //app.UseDefaultFiles();
            app.UseStaticFiles();

            app.UseStaticFiles(new StaticFileOptions()
            {
                FileProvider = new PhysicalFileProvider(Path.Combine(Directory.GetCurrentDirectory(), "NonRoot")),
                RequestPath = new PathString("/nonroot")
            });


            //FileServer options instead of default and static files
            //FileServerOptions fileServerOptions = new FileServerOptions();
            //fileServerOptions.DefaultFilesOptions.DefaultFileNames.Clear();
            //fileServerOptions.DefaultFilesOptions.DefaultFileNames.Add("Custom.html");
            //app.UseFileServer(fileServerOptions);


            //Raise exception
            //app.Run(async (context) =>
            //{
            //    throw new Exception("Error Occurred while processing your request");
            //});


            app.Use(async (context, next) =>
            {
                logger.LogInformation("Middleware1: Incoming Request");
                await next();
                logger.LogInformation("Middleware1: Outgoing Response");
            });

            app.Use(async (context, next) =>
            {
                logger.LogInformation("Middleware2: Incoming Request");
                await next();
                logger.LogInformation("Middleware2: Outgoing Response");
            });

            app.Map(new PathString("/Hello"), a => a.Use(async (context, next) =>
            {
                logger.LogInformation("Middleware Hello: Incoming Request");
                await context.Response.WriteAsync("Middleware Hello: Incoming Request handled and response generated");
                await next();
                logger.LogInformation("Middleware Hello: Outgoing Response");
            }));

            //app.Map("/Hello2", a => a.Use(async (context, next) =>
            //{
            //    logger.LogInformation("Middleware Hello2: Incoming Request");
            //    await context.Response.WriteAsync("Middleware Hello2: Incoming Request handled and response generated");
            //    await next();
            //    logger.LogInformation("Middleware Hello2: Outgoing Response");
            //}));

            //app.UseWhen(context => context.Request.Path.StartsWithSegments(new PathString("/Hello")), a => a.Use(async (context, next) =>
            //{
            //    logger.LogInformation("Middleware Hello 1: Incoming Request");
            //    await context.Response.WriteAsync("Middleware Hello: Incoming Request handled and response generated");
            //    await next();
            //    logger.LogInformation("Middleware Hello 1: Outgoing Response");
            //}));
            //app.MapWhen(context => context.Request.Path.StartsWithSegments(new PathString("/Hello")), a => a.Use(async (context, next) =>
            //{
            //    logger.LogInformation("Middleware Hello 1: Incoming Request");
            //    await context.Response.WriteAsync("Middleware Hello: Incoming Request handled and response generated");
            //    await next();
            //    logger.LogInformation("Middleware Hello 1: Outgoing Response");
            //}));
            app.Run(async (context) =>
                {
                    await context.Response.WriteAsync("Middleware3: Incoming Request handled and response generated");
                    logger.LogInformation("Middleware3: Incoming Request handled and response generated");
                });

            }
        }
    }
